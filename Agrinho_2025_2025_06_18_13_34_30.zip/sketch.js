let lixos = [];
let lixeiras = [];
let tipos = ['papel', 'plastico', 'organico', 'metal'];
let pontuacao = 0;

function setup() {
  createCanvas(800, 600);
  
  // Criar 4 lixeiras
  for (let i = 0; i < 4; i++) {
    lixeiras.push(new Lixeira(150 + i * 150, height - 100, tipos[i]));
  }

  // Criar lixos aleatórios
  for (let i = 0; i < 6; i++) {
    lixos.push(new Lixo(random(tipos), random(50, width - 50), random(50, 300)));
  }

  textSize(18);
}

function draw() {
  background(220);
  
  fill(0);
  text("Arraste o lixo até a lixeira correta", 20, 30);
  text("Pontuação: " + pontuacao, 20, 60);

  for (let lixeira of lixeiras) {
    lixeira.mostrar();
  }

  for (let lixo of lixos) {
    lixo.mostrar();
    lixo.arrastar();
  }
}

function mousePressed() {
  for (let lixo of lixos) {
    lixo.verificarClique(mouseX, mouseY);
  }
}

function mouseReleased() {
  for (let lixo of lixos) {
    if (lixo.arrastando) {
      for (let lixeira of lixeiras) {
        if (lixeira.contem(lixo)) {
          if (lixeira.tipo === lixo.tipo) {
            pontuacao += 10;
            lixo.pego = true;
          } else {
            pontuacao -= 5;
          }
        }
      }
    }
    lixo.arrastando = false;
  }

  // Remover lixos já coletados
  lixos = lixos.filter(l => !l.pego);
}

class Lixeira {
  constructor(x, y, tipo) {
    this.x = x;
    this.y = y;
    this.tipo = tipo;
    this.cor = {
      papel: color(100, 149, 237),
      plastico: color(255, 165, 0),
      organico: color(34, 139, 34),
      metal: color(192, 192, 192)
    }[tipo];
  }

  mostrar() {
    fill(this.cor);
    rect(this.x, this.y, 100, 100);
    fill(0);
    textAlign(CENTER);
    text(this.tipo.toUpperCase(), this.x + 50, this.y + 55);
  }

  contem(lixo) {
    return (lixo.x > this.x && lixo.x < this.x + 100 &&
            lixo.y > this.y && lixo.y < this.y + 100);
  }
}

class Lixo {
  constructor(tipo, x, y) {
    this.tipo = tipo;
    this.x = x;
    this.y = y;
    this.arrastando = false;
    this.offsetX = 0;
    this.offsetY = 0;
    this.pego = false;
  }

  mostrar() {
    fill(255);
    stroke(0);
    ellipse(this.x, this.y, 40);
    fill(0);
    textAlign(CENTER, CENTER);
    text(this.tipo.charAt(0).toUpperCase(), this.x, this.y);
  }

  verificarClique(mx, my) {
    let d = dist(mx, my, this.x, this.y);
    if (d < 20) {
      this.arrastando = true;
      this.offsetX = this.x - mx;
      this.offsetY = this.y - my;
    }
  }

  arrastar() {
    if (this.arrastando) {
      this.x = mouseX + this.offsetX;
      this.y = mouseY + this.offsetY;
    }
  }
}
